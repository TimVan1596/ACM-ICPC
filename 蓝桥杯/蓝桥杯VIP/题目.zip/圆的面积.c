#include <stdio.h>
#define PI 3.14159265358979323

int main()
{
    int n;
    scanf("%d", &n);
    printf("%.7f", n * n * PI);
    return 0;
}
