package com.timvan.Java方向班.Alogrithm0218;

import java.util.Scanner;

/**
 * @author TimVan
 * @date 2019/2/18 16:29
 */
public class Six_判转换成大写字母 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String str =  scanner.next();
        System.out.println(str.toUpperCase());
    }
}
