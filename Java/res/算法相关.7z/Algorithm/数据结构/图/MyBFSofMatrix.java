package com.timvan.Algorithm.数据结构.图;

/**
 * @description:邻接矩阵的广度优先搜索
 * @author: Tim Van
 * @create: 2019-04-15 01:06
 **/
public class MyBFSofMatrix {


    public static void main(String[] args) {
//        char[] vertices = {'A','B','C','D','E','F','G'};
//        char[][] matrix = {
//                {'A','C'},
//                {'A','D'},
//                {'A','F'},
//                {'C','B'},
//                {'F','G'},
//                {'G','E'},
//        };
//
//
//        GraphMatrix graphMatrix = new GraphMatrix(vertices,matrix);
//        BFS(graphMatrix);
    }
}
