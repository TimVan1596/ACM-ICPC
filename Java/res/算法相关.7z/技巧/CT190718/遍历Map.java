package com.timvan.����.CT190718;

public class ����Map {
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}
